package org.eyalgo.datetime;

public enum YearQuarter {
    Q1, Q2, Q3, Q4;
}
