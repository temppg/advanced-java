package org.eyalgo.datetime;

import java.util.Calendar;

public class SampleTwo {

	@SuppressWarnings("unused")
	
	
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		cal.set(2014, Calendar.JULY, 14, 12, 30);
		
		int lectureIsOneHour = 1; // ??
		
		int years = 3;
		int months = 6;
	}

}
